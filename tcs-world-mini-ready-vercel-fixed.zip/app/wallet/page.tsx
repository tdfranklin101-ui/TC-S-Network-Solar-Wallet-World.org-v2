'use client';

import { useEffect, useState } from 'react';
import { kWhToRays, fmtSolar, ONE_SOLAR_KWH } from '@/lib/units';

export const dynamic = "force-dynamic";
export const fetchCache = "force-no-store";

export default function WalletPage() {
  const [data, setData] = useState<any>(null);
  useEffect(() => {
    (async () => {
      const r = await fetch('/api/wallet/balance');
      const d = await r.json();
      setData(d);
    })();
  }, []);

  const kwh = data?.kwh ?? 0;
  const rays = kWhToRays(kwh);
  const solar = kwh / ONE_SOLAR_KWH;

  return (
    <main className="space-y-6">
      <div className="card">
        <h2 className="text-xl font-semibold mb-2">Wallet</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
          <div className="p-4 rounded-xl bg-white/5">
            <div className="text-white/70 text-sm">kWh Balance</div>
            <div className="text-2xl font-bold">{kwh.toFixed(3)}</div>
          </div>
          <div className="p-4 rounded-xl bg-white/5">
            <div className="text-white/70 text-sm">Rays</div>
            <div className="text-2xl font-bold">{rays.toFixed(2)}</div>
          </div>
          <div className="p-4 rounded-xl bg-white/5">
            <div className="text-white/70 text-sm">Solar</div>
            <div className="text-2xl font-bold">{fmtSolar(solar)}</div>
          </div>
        </div>
      </div>
      <div className="card">
        <button className="btn" onClick={async () => { await fetch('/api/wallet/daily'); location.reload(); }}>
          Claim Daily Solar (GBI)
        </button>
      </div>
    </main>
  );
}
