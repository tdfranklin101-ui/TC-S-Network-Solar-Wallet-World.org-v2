import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "TC‑S World Mini",
  description: "Solar-indexed marketplace and situationally-aware wallet for World.org",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="container-narrow py-8">
          <header className="mb-6 flex items-center justify-between">
            <h1 className="text-2xl font-bold">TC‑S • World Mini</h1>
            <nav className="text-sm space-x-4">
              <a className="link" href="/">Home</a>
              <a className="link" href="/identify">Identify</a>
              <a className="link" href="/market">Market</a>
              <a className="link" href="/wallet">Wallet</a>
            </nav>
          </header>
          {children}
          <footer className="mt-10 text-xs text-white/70">
            1 Solar = 4,913 kWh • © TC‑S Network
          </footer>
        </div>
      </body>
    </html>
  );
}
