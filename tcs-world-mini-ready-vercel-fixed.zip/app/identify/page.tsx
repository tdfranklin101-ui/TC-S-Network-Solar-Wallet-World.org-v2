'use client';
import { useState } from 'react';

export const dynamic = "force-dynamic";

export default function IdentifyPage() {
  const [desc, setDesc] = useState('');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const r = await fetch('/api/identify', { method: 'POST', body: JSON.stringify({ desc }) });
    const data = await r.json();
    setResult(data);
    setLoading(false);
  }

  return (
    <main className="space-y-6">
      <div className="card">
        <h2 className="text-xl font-semibold mb-4">Identify</h2>
        <p className="mb-4 text-white/80">Paste a description. The AI estimates kWh usage and proposes a Solar-indexed price.</p>
        <form onSubmit={onSubmit} className="space-y-3">
          <textarea className="w-full rounded-xl p-3 text-black" rows={5}
            placeholder="Describe your digital artifact (e.g., 'AI music track, 3 minutes...')"
            value={desc} onChange={e => setDesc(e.target.value)} />
          <button className="btn" disabled={loading} type="submit">{loading? 'Estimating…' : 'Estimate & Propose Price'}</button>
        </form>
      </div>
      {result && (
        <div className="card">
          <pre className="whitespace-pre-wrap">{JSON.stringify(result, null, 2)}</pre>
        </div>
      )}
    </main>
  );
}
