export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <main className="space-y-6">
      <div className="card">
        <h2 className="text-xl font-semibold mb-2">TC‑S World Mini</h2>
        <p>Identify items, price them in kWh → Solar → Rays, and trade in the Market with the situationally‑aware wallet.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <a href="/identify" className="card">Identify<br/><span className="text-white/70">Open Identify</span></a>
        <a href="/market" className="card">Market<br/><span className="text-white/70">Open Market</span></a>
        <a href="/wallet" className="card">Wallet<br/><span className="text-white/70">Open Wallet</span></a>
      </div>
    </main>
  );
}
