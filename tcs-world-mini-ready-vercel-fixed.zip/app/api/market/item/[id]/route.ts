import { NextResponse } from 'next/server';
import { supabaseService } from '@/lib/supabase-server';

export const runtime = 'nodejs';

export async function GET(_req: Request, context: { params: { id: string } }) {
  const { id } = context.params;
  try {
    const sb = supabaseService();
    const { data, error } = await sb
      .from('tcs_items')
      .select('id,title,description,rays_price,owner_wallet')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    return NextResponse.json(data ?? null);
  } catch (e: any) {
    console.error('market/item error', e?.message || e);
    return NextResponse.json(null, { status: 200 });
  }
}
