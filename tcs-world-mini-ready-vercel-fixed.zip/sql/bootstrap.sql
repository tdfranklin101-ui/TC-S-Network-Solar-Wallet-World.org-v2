-- TC‑S World Mini • Bootstrap schema & helpers (idempotent)

-- Tables
create table if not exists tcs_balances(
  wallet_id uuid primary key,
  kwh numeric not null default 0
);

create table if not exists tcs_items(
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text default '',
  rays_price integer not null default 0,
  owner_wallet uuid
);

-- Functions

-- Increment balance safely
create or replace function tcs_increment_balance(p_wallet_id uuid, p_kwh numeric)
returns void language plpgsql as $$
begin
  insert into tcs_balances(wallet_id, kwh) values (p_wallet_id, p_kwh)
  on conflict (wallet_id) do update set kwh = tcs_balances.kwh + excluded.kwh;
end; $$;

-- Transfer between wallets atomically
create or replace function tcs_transfer(p_from uuid, p_to uuid, p_kwh numeric)
returns void language plpgsql as $$
begin
  update tcs_balances set kwh = kwh - p_kwh where wallet_id = p_from;
  insert into tcs_balances(wallet_id, kwh) values (p_to, p_kwh)
  on conflict (wallet_id) do update set kwh = tcs_balances.kwh + excluded.kwh;
end; $$;

-- Execute arbitrary SQL (seed helper; consider removing in prod)
create or replace function tcs_exec_sql(p_sql text)
returns void language plpgsql as $$
begin
  execute p_sql;
end; $$;
